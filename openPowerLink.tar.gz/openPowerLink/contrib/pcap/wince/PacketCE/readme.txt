Original version from http://www.winpcap.org/install/bin/PacketCE.zip
